#include "tensor/placement.h"

Placement::~Placement() = default;
