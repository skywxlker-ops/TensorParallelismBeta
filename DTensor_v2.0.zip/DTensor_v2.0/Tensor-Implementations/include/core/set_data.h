#pragma once

#include "core/Tensor.h"
#include "device/DeviceTransfer.h"
#include "dtype/fp4.h"
#include <iostream>
#include <cstring>
#include <vector>

namespace OwnTensor
{
    // template <>
    // inline void Tensor::set_data<float4_e2m1_2x_t>(const std::vector<float4_e2m1_2x_t>& src)
    // {

    // }

    
}