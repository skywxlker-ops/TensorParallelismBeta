#include "ckpt.h"
// Empty for now — implementation in header for simplicity.
